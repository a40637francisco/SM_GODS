Codificadores e descodificadores (vers�es execut�veis a 64 bit)
-------------------------------------------------------------------

Sintaxe de utiliza��o para codifica��o:
#.exe ficheiro_entrada  ficheiro_saida

Sintaxe de utiliza��o para descodifica��o:
#.exe ficheiro_entrada  ficheiro_saida

Huff64_Enc.exe  - Codificador Semi-Adaptativo de Huffman, ao n�vel do s�mbolo
Huff64_Dec.exe  - Descodificador Semi-Adaptativo de Huffman, ao n�vel do s�mbolo

AHuff64_Enc.exe  - Codificador Adaptativo de Huffman, ao n�vel do s�mbolo
AHuff64_Dec.exe  - Descodificador Adaptativo de Huffman, ao n�vel do s�mbolo

Arith64_Enc.exe  - Codificador Semi-Adaptativo Aritm�tico, ao n�vel do s�mbolo
Arith64_Dec.exe  - Descodificador Semi-Adaptativo Aritm�tico, ao n�vel do s�mbolo



 
